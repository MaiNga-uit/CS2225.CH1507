
vn_fruits - v3 fruit_240x240_noise_bright
==============================

This dataset was exported via roboflow.ai on December 21, 2020 at 3:14 AM GMT

It includes 1498 images.
Vn-fruits are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 240x240 (Fit (black edges))

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -25 and +25 percent
* Salt and pepper noise was applied to 5 percent of pixels


